## Module <subscription_package>
#### 12.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial commit for Subscription Management 

#### 12.04.2024
#### Version 17.0.1.0.1
#### Update
- Bug Fix

#### 13.06.2024
#### Version 17.0.1.1.2
#### Update
- Bug Fix, fixed issue in invoicing the subscription sale order multiple times, made the next_invoice_date field in the model subscription.package editable, updated context in xml files.

#### 14.08.2024
#### Version 17.0.2.1.2
#### Update
-  Added Paused feature.

#### 17.12.2024
#### Version 17.0.3.1.2
#### Update
-  Updated with the issue in unit price.
