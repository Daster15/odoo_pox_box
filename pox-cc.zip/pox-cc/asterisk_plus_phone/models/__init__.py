# -*- coding: utf-8 -*-
from . import call
from . import favorite
from . import recently_call
from . import res_partner
from . import res_users
from . import settings
from . import user
