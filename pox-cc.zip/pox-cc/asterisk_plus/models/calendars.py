
from odoo import models, fields, api, _


class Calendars(models.Model):
    _name = 'easy_cc.calendar'
    _description = 'calendars setup'

    name = fields.Char(string="Calendar name", required=True)
    calendar_active = fields.Boolean(string="Calendar active", required=True)
    calendar_days_ids = fields.One2many('easy_cc.calendar_days', 'calendar_id', string="CalendarDays")


class CalendarDays(models.Model):
    _name = 'easy_cc.calendar_days'

    weekday = fields.Selection(string='Week Day',
                                    selection=[('Monday', 'Mon'),
                                               ('Tuesday', 'Tue'),
                                               ('Wednesday', 'Wed'),
                                               ('Thursday', 'Thu'),
                                               ('Friday', 'Fri'),
                                               ('Saturday', 'Sat'),
                                               ('Sunday', 'Sun')],
                                    required=True)
    start_time = fields.Float(string="Start Time",required=True)
    stop_time = fields.Float(string="Stop Time",required=True)
    calendar_id = fields.Many2one('easy_cc.calendar', string="Calendar")
