
from odoo import models, fields, api, _


class IvrMainTables(models.Model):
    _name = 'easy_cc.ivr_main_tables'
    _description = 'ivr menu setup'

    ivr_name = fields.Char(string="Ivr name", required=True)
    ivr_max_input_digits_length = fields.Char(string="Max input digits length", required=True)
    ivr_timeout_sec = fields.Integer(string="Timeout sec", required=True)
    ivr_no_action_transfer = fields.Selection(selection='_callcenter_actions', string="No dtmf key action", required=True)
    fail_action = fields.Selection(selection='_callcenter_actions', string="Wrong dtmf key action", required=True)
    ivr_sound = fields.Many2one('easy_cc.sounds', string="Ivr sound")
    calendar_id = fields.Many2one('easy_cc.calendar', string="Calendar")
    calendar_tree_ids = fields.One2many('easy_cc.ivr_tree_tables', 'ivr_main_tables_id', string="DtmfKeys")

    def _callcenter_actions(self):
        sounds = self.env['easy_cc.sounds'].search([])
        ivrs = self.env['easy_cc.ivr_main_tables'].search([])
        callcenters = self.env['easy_cc.callcenters'].search([])
        users = self.env['asterisk_plus.user'].search([])
        fifos = self.env['easy_cc.fifos'].search([])
        lst = []
        for task in sounds:
            lst.append(("Play_" + task.name, "Play_" + task.name))
        for ivr in ivrs:
            lst.append(("IVR_" + ivr.ivr_name, "IVR_" + ivr.ivr_name))
        for callcenter in callcenters:
            lst.append(("CallCenter_" + callcenter.queue_name, "CallCenter_" + callcenter.queue_name))
        for user in users:
            lst.append(("User_" + user.name, "User_" + user.name))
        for fifo in fifos:
            lst.append(("Fifo_" + fifo.fifo_name, "Fifo_" + fifo.fifo_name))
        lst.append(("CallBackIVR", "CallBackIVR"))
        return lst


class IvrTreeTables(models.Model):
    _name = 'easy_cc.ivr_tree_tables'

    dtmf_key = fields.Integer(string='Dtmf key', required=True)
    dtmf_action = fields.Selection(selection='_callcenter_actions', string="Action", required=True)
    ivr_main_tables_id = fields.Many2one('easy_cc.ivr_main_tables', string="IvrMain")

    def _callcenter_actions(self):

        sounds = self.env['easy_cc.sounds'].search([])
        ivrs = self.env['easy_cc.ivr_main_tables'].search([])
        callcenters = self.env['easy_cc.callcenters'].search([])
        users = self.env['asterisk_plus.user'].search([])
        fifos = self.env['easy_cc.fifos'].search([])
        lst = []
        for task in sounds:
            lst.append(("Play_" + task.name, "Play_" + task.name))
        for ivr in ivrs:
            lst.append(("IVR_" + ivr.ivr_name, "IVR_" + ivr.ivr_name))
        for callcenter in callcenters:
            lst.append(("CallCenter_" + callcenter.queue_name, "CallCenter_" + callcenter.queue_name))
        for user in users:
            lst.append(("User_" + user.name, "User_" + user.name))
        for fifo in fifos:
            lst.append(("Fifo_" + fifo.fifo_name, "Fifo_" + fifo.fifo_name))
        lst.append(("CallBackIVR", "CallBackIVR"))
        return lst
