
from odoo import models, fields, api, _


class Fifo(models.Model):
    _name = 'easy_cc.fifos'
    _description = 'fifo setup'

    fifo_name = fields.Char(string="Queue name", required=True)
    fifo_no_free_agents_sound = fields.Many2one('easy_cc.sounds', string="No free agents",required=True)
    fifo_no_free_agents_repeat_time = fields.Integer(string='No free agents repeat time', required=True)
    fifo_no_answer_wait_time = fields.Integer(string='Fifo no answer time', required=True)
    fifo_no_answer_call_to = fields.Selection(selection='_callcenter_actions', string="No answer action", required=True)
    fifo_impatient_callers_dtmf_key = fields.Integer(string='Dtmf key for impatient callers', required=True)
    fifo_customer_announcement_sound = fields.Many2one('easy_cc.sounds', string="Fifo customer announcement sound")
    fifo_agent_announcement_sound = fields.Many2one('easy_cc.sounds', string="Fifo agent announcement sound")
    fifo_moh = fields.Many2one('easy_cc.sounds', string="Fifo moh sound")
    fifo_active = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Fifo active',required=True)

    fifo_agents_ids = fields.One2many('easy_cc.fifo_users', 'fifo_id', string="Agents")

    def _callcenter_actions(self):

        sounds = self.env['easy_cc.sounds'].search([])
        ivrs = self.env['easy_cc.ivr_main_tables'].search([])
        callcenters = self.env['easy_cc.callcenters'].search([])
        users = self.env['asterisk_plus.user'].search([])
        fifos = self.env['easy_cc.fifos'].search([])
        lst = []
        for task in sounds:
            lst.append(("Play_" + task.name, "Play_" + task.name))
        for ivr in ivrs:
            lst.append(("IVR_" + ivr.ivr_name, "IVR_" + ivr.ivr_name))
        for callcenter in callcenters:
            lst.append(("CallCenter_" + callcenter.queue_name, "CallCenter_" + callcenter.queue_name))
        for user in users:
            lst.append(("User_" + user.name, "User_" + user.name))
        for fifo in fifos:
            lst.append(("Fifo_" + fifo.fifo_name, "Fifo_" + fifo.fifo_name))
        lst.append(("CallBackIVR", "CallBackIVR"))
        return lst


class FifoUsers(models.Model):
    _name = 'easy_cc.fifo_users'

    user_id = fields.Many2one('asterisk_plus.user', string="Fifo agent", required=True)
    fifo_id = fields.Many2one('easy_cc.fifos', string="Fifo")


