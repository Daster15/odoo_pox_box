
from odoo import models, fields, api, _
from urllib.parse import urljoin, quote
import uuid
import logging

class Sounds(models.Model):
    _name = 'easy_cc.sounds'
    _description = 'Sounds for PBX Call Center Setup'

    name = fields.Char(required=True)
    sound = fields.Binary(string="Audio Files",required=True)
    sound_name = fields.Char(string="Audio Name",required=True)
    recording_widget = fields.Html(compute='_get_recording_widget', string='Recording', sanitize=False)
    recording_access_url = fields.Char()
    file_path = fields.Char(readonly=True)

    

    _sql_constraints = [
        ('name_uniq', 'unique (name)', _('The name of sound must be unique!')),
    ]

    def _get_recording_widget(self):
        for rec in self:
            try:
                recording_source = 'sound' if rec.sound else 'sound_name'
                if rec.sound or rec.sound_name:
                    # Odoo stored recording, create a local URL.
                    rec.recording_widget = '<audio id="sound_file" preload="auto" ' \
                        'controls="controls"> ' \
                        '<source src="/web/content?model=easy_cc.sounds&' \
                        'id={recording_id}&filename={filename}&field={source}&' \
                        'filename_field=recording_filename&download=True" />' \
                        '</audio>'.format(
                            recording_id=rec.id,
                            filename=rec.sound_name,
                            source=recording_source)
                else:
                    # Remotely stored recording, create a link to the remote URL
                    recording_url = urljoin(rec.recording_access_url, quote(rec.file_path))
                    rec.recording_widget = '<audio id="sound_file" preload="auto" ' \
                        'controls="controls"><source src="{}"/></audio>'.format(recording_url)
            except Exception as e:
               # logger.exception('Recording widget error:')
                rec.recording_widget = ''

    @api.model
    def create(self, vals):
        res = super(Sounds, self).create(vals)
        return res