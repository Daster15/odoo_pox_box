
from odoo import models, fields, api, _


class CallCenter(models.Model):
    _name = 'easy_cc.callcenters'
    _description = 'call center setup'

    queue_name = fields.Char(string="Queue name", required=True)
    ring_strategy = fields.Selection(selection='_callcenter_strategy', string="Call center strategy", required=True)
    callcenter_moh_sound = fields.Many2one('easy_cc.sounds', string="Callcenter moh sound",required=True)
    announce_position = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Announce caller position',required=True)
    queue_active = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Queue active',required=True)
    max_wait_time = fields.Integer(string='Max wait time', required=True)
    max_wait_time_with_no_agent = fields.Integer(string='Max time with no agent', required=True)
    max_wait_time_with_no_agent_time_reached = fields.Integer(string='Max time with no agent reached', required=True)
    callcenter_agents_ids = fields.One2many('easy_cc.callcenter_users', 'callcenter_id', string="Agents")

    def _callcenter_strategy(self):

         return [("ring-all", "ring-all"),
                 ("longest-idle-agent","longest-idle-agent"),
                 ("round-robin","round-robin"),
                 ("top-down","top-down"),
                 ("agent-with-least-talk-time","agent-with-least-talk-time"),
                 ("agent-with-fewest-calls","agent-with-fewest-calls"),
                 ("sequentially-by-agent-order","sequentially-by-agent-order"),
                 ("random","random"),
                 ("ring-progressively","ring-progressively")]


class CallcenterAgents(models.Model):
    _name = 'easy_cc.callcenter_users'

    user_id = fields.Many2one('asterisk_plus.user', string="Callcenter agent", required=True)
    callcenter_id = fields.Many2one('easy_cc.callcenters', string="IvrMain")


