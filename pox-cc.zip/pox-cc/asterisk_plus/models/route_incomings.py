
from odoo import models, fields, api, _

class RouteIncomings(models.Model):
    _name = 'easy_cc.route_incomings'
    _description = 'Routing incoming to PBX Call Center Setup'

    name = fields.Char(required=True)
    did_cid_number = fields.Char(required=True)
    call_to_intime = fields.Selection(selection='_get_actions', string="Call Action")
    route_type = fields.Char(required=True)
    dialplan_number = fields.Char(required=True)
    numbers_to_dialplan = fields.Char(required=True)
    dialplan_context_name = fields.Char(required=True)
    before_connection_sound = fields.Many2one('easy_cc.sounds', string="Before connection sound",required=True)
    after_hours_sound = fields.Many2one('easy_cc.sounds', string="After hours sound",required=True)
    transfer_after_hours = fields.Selection(selection='_get_actions', string="After hours call action")
    calendar = fields.Many2one('easy_cc.calendar', string="Calendar",required=True)
   

    _sql_constraints = [
        ('did_cid_number_uniq', 'unique (did_cid_number)', _('The did_cid_number of routing must be unique!')),
    ]


    def _get_actions(self):
        sounds = self.env['easy_cc.sounds'].search([])
        ivrs = self.env['easy_cc.ivr_main_tables'].search([])
        callcenters = self.env['easy_cc.callcenters'].search([])
        users = self.env['asterisk_plus.user'].search([])
        fifos = self.env['easy_cc.fifos'].search([])
        lst = []
        for task in sounds:
            lst.append(("Play_" + task.name, "Play_" + task.name))
        for ivr in ivrs:
            lst.append(("IVR_" + ivr.ivr_name, "IVR_" + ivr.ivr_name))
        for callcenter in callcenters:
            lst.append(("CallCenter_" + callcenter.queue_name, "CallCenter_" + callcenter.queue_name))
        for user in users:
            lst.append(("User_" + user.name, "User_" + user.name))
        for fifo in fifos:
            lst.append(("Fifo_" + fifo.fifo_name, "Fifo_" + fifo.fifo_name))
        lst.append(("CallBackIVR", "CallBackIVR"))
        return lst